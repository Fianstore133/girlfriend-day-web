function showHeart() {
  const heart = document.createElement("div");
  heart.className = "heart";
  heart.innerText = "💖";
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.top = "80vh";
  document.getElementById("love-container").appendChild(heart);
  setTimeout(() => heart.remove(), 2000);
}

function addEffect(audio) {
  let interval;
  audio.addEventListener("play", () => {
    interval = setInterval(showHeart, 300);
  });
  audio.addEventListener("pause", () => clearInterval(interval));
  audio.addEventListener("ended", () => clearInterval(interval));
}

addEffect(document.getElementById("fian"));
addEffect(document.getElementById("nadin"));